# My First Project > 2025-03-31 3:16pm
https://universe.roboflow.com/ai4h/my-first-project-jzo3i

Provided by a Roboflow user
License: CC BY 4.0

